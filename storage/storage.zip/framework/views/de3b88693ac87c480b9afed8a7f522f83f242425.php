<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <title>Josh Admin</title>
    <!-- Jquery Framework -->
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <!-- API 2 -->
    <script type="text/javascript" src="http://www.stampready.net/api2/api.js"></script>
    <style>
        @import  url('https://fonts.googleapis.com/css?family=Montserrat');
        @import  url('https://fonts.googleapis.com/css?family=Open Sans');
    </style>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>

</html>
