<?php

/**
* Language file for group delete modal
*
*/
return array(

    'title'         => 'Verwijder groep',
    'body'			=> 'Weet je zeker dat je deze groep wilt verwijderen? Deze actie is niet terug te draaien.',
    'cancel'		=> 'Cancel',
    'confirm'		=> 'Verwijder',

);
