<?php
/**
* Language file for blog section titles
*
*/

return array(

	'title'			=> 'Titel',
    'create'			=> 'Maak een nieuwe blog categorie',
    'edit' 				=> 'Wijzig blog categorie',
    'management'	=> 'Beheer uw blog categorieën',
    
);
