<?php
/**
* Language file for group table headings
*
*/

return array(

    'id'         => 'Id',
    'name'       => 'Nome',
    'users'      => 'No. de Usuários',
    'created_at' => 'Criado em',
    'actions'	 => 'Ações',

);
