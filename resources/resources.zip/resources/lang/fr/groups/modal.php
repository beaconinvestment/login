<?php

/**
* Language file for group delete modal
*
*/
return array(

    'title'         => 'Supprimer le groupe',
    'body'			=> 'Êtes-vous sûr de vouloir supprimer ce groupe ? Cette opération est irréverssible.',
    'cancel'		=> 'Annuler',
    'confirm'		=> 'Supprimer',

);
