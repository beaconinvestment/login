<?php

/**
* Language file for blog delete modal
*
*/
return array(

    'body'			=> 'Êtes-vous sûr de vouloir supprimer ce blog ? Cette opération est irréverssible.',
    'cancel'		=> 'Annuler',
    'confirm'		=> 'Supprimer',
    'title'         => 'Supression du blog',

);
