<?php
/**
* Language file for group table headings
*
*/

return array(

    'id'         => 'Id',
    'name'       => 'Nombre',
    'users'      => 'N° de Usuarios',
    'created_at' => 'Creado el',
    'actions'	 => 'Acciones',

);
