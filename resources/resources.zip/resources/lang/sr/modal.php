<?php

/**
 * Language file for delete modal
 *
 */
return array(

    'title'         => 'Obri�i stavku',
    'body'			=> 'Da li ste sigurni da �elite obrisati stavku? Ova operacija je bespovratna.',
    'cancel'		=> 'Odustani',
    'confirm'		=> 'Obri�i',

);
