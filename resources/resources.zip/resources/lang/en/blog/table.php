<?php
/**
* Language file for blog category table headings
*
*/

return array(

    'id'         => 'Id',
    'title'       => 'Title',
    'comments'      => 'No. of Comments',
    'created_at' => 'Created at',
    'actions'	 => 'Actions',
    'view-blog-comment' => 'view blog & comments',
    'update-blog' => 'update blog',
    'delete-blog' => 'delete blog'

);
