<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Gruppen Name',
    'slug'          => 'Slug',
    'general' 		=> 'Allgemein',
    'permissions'	=> 'Berechtigungen',

);
