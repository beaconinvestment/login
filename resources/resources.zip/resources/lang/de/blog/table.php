<?php
/**
* Language file for blog category table headings
*
*/

return array(

    'id'         => 'Id',
    'title'       => 'Titel',
    'comments'      => 'Anzahl der Kommentare',
    'created_at' => 'Erstellt am',
    'actions'	 => 'Aktionen',

);
